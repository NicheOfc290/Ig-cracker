hello this tool is made by @God_x_Gamer 
channel @GxTools 

how To Use 
1- install termux and setup it using comands 
2- now take a combo file 
what is combo file :? 
a file which contains different username email password number
like 
username:pass
number:pass
email@:pass

3- copy your combo file in this folder 
now open termux 
and locate and open this directory
and type" python Cracker.py"

4- there it will install some pips and modules
after that you will redirected to my channel @gxtools

you have to join the channel before using script

now enter your telegram Id 
you can get your telegram id easily using @telegramrawdatabot or @sangmatabot

5- enter you telegram id 
6- enter combo file name their

and tool will start 

Note :- You Must Start @GxToolsBot before Using Tool Because All The Hits Will Be send To Your Account Via This Bot
So start The Bot Before Starting Script

Q- how to bypass ip ban in mobile 
only working with mobile network not wifi? 

so bypassing ip ban in Non Root mobile is very easy using macrodroid app 


if any other query dm @God_x_Gamer


